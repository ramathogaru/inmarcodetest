package com.inmar.test.model;

public class Location {
	private int location_id;
	private String location_name;

	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getLocation_id() {
		return location_id;
	}

	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}

	public String getLocation_name() {
		return location_name;
	}

	public Location(int location_id, String location_name) {
		super();
		this.location_id = location_id;
		this.location_name = location_name;
	}

	public void setLocation_name(String location_name) {
		this.location_name = location_name;
	}

	@Override
	public String toString() {
		return "Location [location_id=" + location_id + ", location_name=" + location_name + "]";
	}
}
