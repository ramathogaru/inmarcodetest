package com.inmar.test.repository;

import java.util.List;

import com.inmar.test.model.Location;

public interface LocationRepository {
	int save(Location location);

	int update(Location location);

	Location findById(int id);
	
	List<Location> findAll();

	int deleteById(int id);

	int deleteAll();
}
