package com.inmar.test.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inmar.test.model.Location;

@Repository
public class JdbcLocationRepository implements LocationRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(Location location) {
		return jdbcTemplate.update("INSERT INTO Location (location_id, location_name) VALUES(?,?)",
				new Object[] { location.getLocation_id(), location.getLocation_name() });
	}

	@Override
	public int update(Location location) {
		return jdbcTemplate.update("UPDATE Location SET location_name=? WHERE location_id=?",
				new Object[] { location.getLocation_name(), location.getLocation_id() });
	}

	@Override
	public Location findById(int id) {
		try {
			Location location = jdbcTemplate.queryForObject("SELECT * FROM Location WHERE location_id=?",
					BeanPropertyRowMapper.newInstance(Location.class), id);

			return location;
		} catch (IncorrectResultSizeDataAccessException e) {
			return null;
		}
	}

	@Override
	public List<Location> findAll() {
		return jdbcTemplate.query("SELECT * from Location", BeanPropertyRowMapper.newInstance(Location.class));
	}

	@Override
	public int deleteById(int id) {
		return jdbcTemplate.update("DELETE FROM Location WHERE location_id=?", id);
	}

	@Override
	public int deleteAll() {
		return jdbcTemplate.update("DELETE from Location");
	}

}
