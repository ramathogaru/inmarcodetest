package com.inmar.test.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inmar.test.model.SubCategory;

@Repository
public class JdbcSubCategoryRepository implements SubCategoryRepository{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	
	@Override
	public int save(SubCategory subCategory, int categoryId) {
		jdbcTemplate.update("INSERT INTO SubCategory (subcategory_id, subcategory_name) VALUES(?,?)",
				new Object[] { subCategory.getSubcategory_id(), subCategory.getSubcategory_name() });
		return jdbcTemplate.update("INSERT INTO category_SubCategory (category_id , SubCategory_id  ) VALUES(?,?)",
				new Object[] { categoryId, subCategory.getSubcategory_id() });
	}

}
