package com.inmar.test.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inmar.test.model.Category;

@Repository
public class JdbcCategoryRepository implements CategoryRepository{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public int save(Category category, int department_id) {
		jdbcTemplate.update("INSERT INTO Category (category_id, category_name) VALUES(?,?)",
				new Object[] { category.getCategory_id(), category.getCategory_name() });
		return jdbcTemplate.update("INSERT INTO department_category (department_id, category_id ) VALUES(?,?)",
				new Object[] { department_id, category.getCategory_id() });
	}

	@Override
	public List<Category> findCategoriesByDepartmentId(int department_id) {
		return jdbcTemplate.query(
				"SELECT * from Category where category_id in ( select category_id from department_category where department_id = ?) ",
				BeanPropertyRowMapper.newInstance(Category.class), department_id);
	}

	@Override
	public int deleteById(int category_id) {
		jdbcTemplate.update("DELETE FROM Department_Category WHERE Category_id=?", category_id);
		return jdbcTemplate.update("DELETE FROM Category WHERE Category_id=?", category_id);
		
	}

}
