package com.inmar.test.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inmar.test.model.Department;

@Repository
public class JdbcDepartmentRepository implements DepartmentRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(Department Department, int location_id) {
		jdbcTemplate.update("INSERT INTO Department (department_id, department_name) VALUES(?,?)",
				new Object[] { Department.getDepartment_id(), Department.getDepartment_name() });
		return jdbcTemplate.update("INSERT INTO location_department (location_id, department_id) VALUES(?,?)",
				new Object[] { location_id, Department.getDepartment_id() });
	}

	@Override
	public int update(Department Department) {
		return jdbcTemplate.update("UPDATE Department SET Department_name=? WHERE Department_id=?",
				new Object[] { Department.getDepartment_name(), Department.getDepartment_id() });
	}

	@Override
	public Department findById(int id) {
		try {
			Department Department = jdbcTemplate.queryForObject("SELECT * FROM Department WHERE Department_id=?",
					BeanPropertyRowMapper.newInstance(Department.class), id);

			return Department;
		} catch (IncorrectResultSizeDataAccessException e) {
			return null;
		}
	}

	@Override
	public List<Department> findAll() {
		return jdbcTemplate.query("SELECT * from Department", BeanPropertyRowMapper.newInstance(Department.class));
	}

	@Override
	public int deleteById(int id) {
		jdbcTemplate.update("DELETE FROM location_Department WHERE Department_id=?", id);
		return jdbcTemplate.update("DELETE FROM Department WHERE Department_id=?", id);
	}

	@Override
	public int deleteAll() {
		return jdbcTemplate.update("DELETE from Department");
	}

	@Override
	public List<Department> findByLocationId(int location_id) {
		return jdbcTemplate.query(
				"SELECT * from Department where department_id in ( select department_id from location_department where location_id = ?) ",
				BeanPropertyRowMapper.newInstance(Department.class), location_id);
	}

}
