package com.inmar.test.repository;

import java.util.List;

import com.inmar.test.model.Category;

public interface CategoryRepository {
	int save(Category category, int department_id);

	List<Category> findCategoriesByDepartmentId(int department_id);

	int deleteById(int category_id);
}
