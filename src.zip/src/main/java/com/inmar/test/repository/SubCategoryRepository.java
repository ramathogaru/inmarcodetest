package com.inmar.test.repository;

import com.inmar.test.model.SubCategory;

public interface SubCategoryRepository {
	int save(SubCategory subCategory, int categoryId);
}
