package com.inmar.test.repository;

import java.util.List;

import com.inmar.test.model.Department;

public interface DepartmentRepository {
	int save(Department department, int location_id);

	int update(Department department);

	Department findById(int id);

	List<Department> findAll();
	
	List<Department> findByLocationId(int location_id);

	int deleteById(int id);

	int deleteAll();
}
