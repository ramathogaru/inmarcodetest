package com.inmar.test.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inmar.test.model.Category;
import com.inmar.test.model.Department;
import com.inmar.test.model.Location;
import com.inmar.test.model.SubCategory;
import com.inmar.test.repository.CategoryRepository;
import com.inmar.test.repository.DepartmentRepository;
import com.inmar.test.repository.LocationRepository;
import com.inmar.test.repository.SubCategoryRepository;


@RestController
@RequestMapping("/api/v1")
public class APIController {

	private static final Logger logger = LogManager.getLogger(APIController.class);

	@Autowired
	LocationRepository locationRepository;
	
	@Autowired
	DepartmentRepository departmentRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	SubCategoryRepository subcategoryRepository;

	@GetMapping("/location")
	public ResponseEntity<List<Location>> getAllLocations() {

		logger.info("getAllLocations:start");

		List<Location> locationList = null;

		try {
			locationList = locationRepository.findAll();
			if (locationList == null || locationList.isEmpty()) {
				logger.info("getAllLocations:no:locations");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			logger.info("getAllLocations:returning:" + locationList.size() + " locations");
			return new ResponseEntity<>(locationList, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("getAllLocations:Exception:", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/location/{location_id}")
	public ResponseEntity<Location> getLocationnById(@PathVariable("location_id") int location_id) {
		try {
			Location location = locationRepository.findById(location_id);

			if (location != null) {
				return new ResponseEntity<>(location, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("getLocationnById:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/location")
	public ResponseEntity<String> createLocation(@RequestBody Location location) {
		try {
			locationRepository.save(location);
			return new ResponseEntity<>("Location was created successfully.", HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("createLocation:Exception:", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PutMapping("/location")
	public ResponseEntity<String> updateLocation(@RequestBody Location location) {

		try {
			Location _location = locationRepository.findById(location.getLocation_id());

			if (_location != null) {
				_location.setLocation_id(location.getLocation_id());
				_location.setLocation_name(location.getLocation_name());

				locationRepository.update(location);
				return new ResponseEntity<>("Location was updated successfully.", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Cannot find Location with location_id=" + location.getLocation_id(),
						HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("updateLocation:Exception:", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@DeleteMapping("/location/{location_id}")
	public ResponseEntity<String> deleteLocation(@PathVariable("location_id") int location_id) {
		try {
			int result = locationRepository.deleteById(location_id);
			if (result == 0) {
				return new ResponseEntity<>("Cannot find Location with location_id=" + location_id, HttpStatus.OK);
			}
			return new ResponseEntity<>("Location was deleted successfully.", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("deleteLocation:Exception:", e);
			return new ResponseEntity<>("Cannot delete Location:" + location_id, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/location")
	public ResponseEntity<String> deleteAllLocations() {
		try {
			int numRows = locationRepository.deleteAll();
			return new ResponseEntity<>("Deleted " + numRows + " Location(s) successfully.", HttpStatus.OK);
		} catch (Exception e) {
			logger.error("deleteAllLocation:Exception:", e);
			return new ResponseEntity<>("Cannot delete Location(s).", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/location/{location_id}/department")
	public ResponseEntity<List<Department>> getDepartmentsByLocationnById(@PathVariable("location_id") int location_id) {
		logger.info("getDepartmentsByLocationnById:location_id:"+location_id);
		try {
			List<Department> departmentList = departmentRepository.findByLocationId(location_id);

			if (departmentList != null) {
				return new ResponseEntity<>(departmentList, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("getDepartmentsByLocationnById:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/location/{location_id}/department")
	public ResponseEntity<String> saveDepartmentsByLocationnById(@PathVariable("location_id") int location_id, @RequestBody Department department ) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				departmentRepository.save(department, location_id);
				return new ResponseEntity<>("Department was saved successfully.", HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("saveDepartmentsByLocationnById:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/location/{location_id}/department")
	public ResponseEntity<String> deleteAllDepartmentsByLocationnById(@PathVariable("location_id") int location_id) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department> departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList ==null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Department Entries Exist for Location.", HttpStatus.OK);
				}else {
					for(Department department:departmentList) {
						departmentRepository.deleteById(department.getDepartment_id());
					}
					return new ResponseEntity<>(departmentList.size()+" Department Entries Deleted for Location.", HttpStatus.OK);
				}
				
			}
		} catch (Exception e) {
			logger.error("saveDepartmentsByLocationnById:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/location/{location_id}/department/{department_id}")
	public ResponseEntity<String> deleteDepartmentsByLocationnByIdDepartmentId(@PathVariable("location_id") int location_id,
			@PathVariable("department_id") int department_id) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department> departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList ==null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Department Entries Exist for Location.", HttpStatus.OK);
				}else {
					Department dept = null;
					for(Department department:departmentList) {
						if(department.getDepartment_id() == department_id){
							dept = department;
							break;
						}
					}
					
					if(dept == null ) {
						return new ResponseEntity<>("Department does not exist for Location.", HttpStatus.FAILED_DEPENDENCY);
					}else {
						departmentRepository.deleteById(department_id);
						return new ResponseEntity<>("Department successfullt Deleted", HttpStatus.OK);
					}
					
				}
				
			}
		} catch (Exception e) {
			logger.error("saveDepartmentsByLocationnById:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/location/{location_id}/department/{department_id}/category")
	public ResponseEntity<String> saveCategory(@PathVariable("location_id") int location_id, @PathVariable("department_id") int department_id,
			@RequestBody Category category ) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department>  departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList == null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Corresponding Departments Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
				}else {
					Department dept = null;
					for(Department dept1:departmentList) {
						if(dept1.getDepartment_id() == department_id) {
							dept  = dept1;
							break;
						}
					}
					
					if( dept == null ) {
						return new ResponseEntity<>("Department Does Not Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
					}else {
						categoryRepository.save(category, department_id);
						return new ResponseEntity<>("Category Saved Successfully.", HttpStatus.OK);
					}
				}
			}
		} catch (Exception e) {
			logger.error("saveCategory:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/location/{location_id}/department/{department_id}/category")
	public ResponseEntity<String> deleteAllCategories(@PathVariable("location_id") int location_id, @PathVariable("department_id") int department_id) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department>  departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList == null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Corresponding Departments Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
				}else {
					Department dept = null;
					for(Department dept1:departmentList) {
						if(dept1.getDepartment_id() == department_id) {
							dept  = dept1;
							break;
						}
					}
					
					if( dept == null ) {
						return new ResponseEntity<>("Department Does Not Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
					}else {
						List<Category> categoryList = categoryRepository.findCategoriesByDepartmentId(dept.getDepartment_id());
						if(categoryList == null || categoryList.isEmpty()) {
							return new ResponseEntity<>("No Corresponding categories Exist for the Department.", HttpStatus.FAILED_DEPENDENCY);
						}else {
							for(Category category:categoryList) {
								categoryRepository.deleteById(category.getCategory_id());
							}
							return new ResponseEntity<>(categoryList.size()+" categories successflly deleted for the Department.", HttpStatus.OK);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("deleteAllCategories:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/location/{location_id}/department/{department_id}/category/{category_id}")
	public ResponseEntity<String> deleteCategoryById(@PathVariable("location_id") int location_id, @PathVariable("department_id") int department_id,
			 @PathVariable("category_id") int category_id
			) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department>  departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList == null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Corresponding Departments Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
				}else {
					Department dept = null;
					for(Department dept1:departmentList) {
						if(dept1.getDepartment_id() == department_id) {
							dept  = dept1;
							break;
						}
					}
					
					if( dept == null ) {
						return new ResponseEntity<>("Department Does Not Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
					}else {
						List<Category> categoryList = categoryRepository.findCategoriesByDepartmentId(dept.getDepartment_id());
						if(categoryList == null || categoryList.isEmpty()) {
							return new ResponseEntity<>("No Corresponding categories Exist for the Department.", HttpStatus.FAILED_DEPENDENCY);
						}else {
							Category category1 = null; 
							for(Category category:categoryList) {
								if(category.getCategory_id() == category_id) {
									category1 = category;
									break;
								}
							}
							if( category1 == null ) {
								return new ResponseEntity<>("Category does not exist for the Department.", HttpStatus.FAILED_DEPENDENCY);
							}else {
								categoryRepository.deleteById(category_id);
								return new ResponseEntity<>("Category successflly deleted.", HttpStatus.OK);
							}
							
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("deleteAllCategories:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/location/{location_id}/department/{department_id}/category/{category_id}/subcategory")
	public ResponseEntity<String> saveSubCategory(@PathVariable("location_id") int location_id, @PathVariable("department_id") int department_id
			, @PathVariable("category_id") int category_id,
			@RequestBody SubCategory subCategory ) {
		try {
			Location location = locationRepository.findById(location_id);
			if( location == null ) {
				return new ResponseEntity<>("Location Does Not Exist.", HttpStatus.FAILED_DEPENDENCY);
			}else {
				List<Department>  departmentList = departmentRepository.findByLocationId(location_id);
				if(departmentList == null || departmentList.isEmpty()) {
					return new ResponseEntity<>("No Corresponding Departments Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
				}else {
					Department dept = null;
					for(Department dept1:departmentList) {
						if(dept1.getDepartment_id() == department_id) {
							dept  = dept1;
							break;
						}
					}
					
					if( dept == null ) {
						return new ResponseEntity<>("Department Does Not Exist for the Location.", HttpStatus.FAILED_DEPENDENCY);
					}else {
						List<Category>  categoryList = categoryRepository.findCategoriesByDepartmentId(dept.getDepartment_id());
						
						if(categoryList == null || categoryList.isEmpty()) {
							return new ResponseEntity<>("No Corresponding Categories Exist for the Department.", HttpStatus.FAILED_DEPENDENCY);
						}else {
							Category  category = null;
							for(Category category1:categoryList) {
								if(category_id == category1.getCategory_id()) {
									category = category1;
									break;
								}
							}
							
							if(category == null ) {
								return new ResponseEntity<>("Category Does Not Exist for the Department.", HttpStatus.FAILED_DEPENDENCY);
							}else {
								subcategoryRepository.save(subCategory, category_id);
								return new ResponseEntity<>("SubCategory Saved Successfully.", HttpStatus.OK);
							}
						}
						
					}
				}
			}
		} catch (Exception e) {
			logger.error("saveCategory:Exception:" + location_id, e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
