package com.inmar.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InmarTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
